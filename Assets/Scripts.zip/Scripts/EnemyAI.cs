using UnityEngine;
using UnityEngine.UI;

public class EnemyAI : MonoBehaviour
{
    public float speed = 2f;
    public float detectionRange = 10f;
    public int maxHealth = 15;
    private int currentHealth;
    private Transform player;

    public Slider healthBar; // Reference to health bar UI

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        currentHealth = maxHealth; // Set health to max at start
        UpdateHealthBar();
    }

    void Update()
    {
        if (player != null && Vector2.Distance(transform.position, player.position) < detectionRange)
        {
            transform.position = Vector2.MoveTowards(transform.position, player.position, speed * Time.deltaTime);
        }
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        UpdateHealthBar();

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    void UpdateHealthBar()
    {
        if (healthBar != null)
        {
            healthBar.value = (float)currentHealth / maxHealth;
        }
    }

    void Die()
    {
        Destroy(gameObject); // Destroy enemy when health reaches 0
    }
}
